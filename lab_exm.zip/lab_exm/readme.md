# lab exm

- ssid and password will be provided to connect to
- exm served at some ip addr provided
  - go to that ip addr -> ipaddr/index.html (don't do at home)
  - read all steps carefully
  - skeleton code provided
  - code and test simultaneously don't compile and run at the end -> good for testing and debugging
  - marks will be given as we send to the server => keep log of that and submit the code with best marks
  - submit as many times as you want -> it will overwrite the previous submission
  - don't submit the code with errors
  - don't submit the code with warnings
  - keep the same file name etc and all that to avoid confusion
    - don't change the file name
  - we are also provided with a eco-server -> fix connectivity, test locally (PLEASE TO PREVENT ANY DISASTERS)
  - eco-server is a local server, if it works fine on that then we can proceed to the test server
  - test-server => has lots of ports (pool of 11101 to 11250) -> please choose some random port
  - at last submit the code on the server via the hyprlink (KEEP THE SAME NAME AS YOU USED TO TESTED ON TEST SERVER)
    - submit src code at src code -> .c
    - submit compiled code at compiled code -> executable/binary

## questions

- marks sena upr dekhaadse?
- final submit link je che enna upr multiple submissions chaale ke khaali test server ma?

## what is provided  ?

### first to connect to the router

- ssid: lab207
- passwd: 12345678

### then go to for futher instructions

- ip addr: 192.168.1.102/index.html
